
library(readr)
library(ggplot2)
library(caret) 

randomFor=function(trainX,trainZ,trainY,testX,testZ,testY)
{
  rctrl1 <- trainControl(method = "cv", number = 3, returnResamp = "all")
  rctrlR <- trainControl(method = "cv", number = 5, returnResamp = "all", search = "random")
  rctrl4 <- trainControl(method = "none")
  test_reg_cv_model <- train(cbind(trainX,trainZ), trainY, 
                             method = "rf", 
                             trControl = rctrl1,
                             preProc = c("center", "scale"),
                             ntree = 20,
                             importance = TRUE)
  test_reg_none_model <- train(cbind(trainX,trainZ), trainY, 
                               method = "rf", 
                               trControl = rctrl4,
                               tuneGrid = test_reg_cv_model$bestTune,
                               preProc = c("center", "scale"),
                               ntree = 20)
  test_reg_none_pred <- predict(test_reg_none_model,  cbind(testX,testZ))
  rf_residual=sum(abs(test_reg_none_pred-testY))*(1/length(testY))*(sd_y)
  return(rf_residual)
}


# Read the CSV files
data=XZ <- read_csv('/work/users/s/a/sampriti/ML_2_drug/Interaction_effect/LOCO/XZ_wtm231.csv')
ydata=y <- read_csv('/work/users/s/a/sampriti/ML_2_drug/Interaction_effect/LOCO/y_wtm231.csv')
XZ <- as.matrix(data)[,-1]
y <- as.matrix(ydata)[,-1]
X=XZ[,1:17]
Z=XZ[,18:dim(XZ)[2]]
residual=lm(y~X[,which(colnames(X)=="MolWt")]+X[,which(colnames(X)=="MolLogP")])$residual ## Since MolLogP and MolWt has linear relationship with Solubility
yused=residual
X <- X[,-c(which(colnames(XZ)=="MolLogP"), which(colnames(XZ)=="MolWt"), 
           which(colnames(XZ)=="MolMR"), which(colnames(XZ)=="NumHeteroatoms"),which(colnames(XZ)=="BalabanJ"))]
sd_y=diff(range(yused))#sd(y)
mean_yused=min(yused)+0.5*sd_y
yused=(yused-mean_yused)/sd_y

ind_valts<-sample(1:nrow(X),800)
  ind_ts  <- ind_valts
  ind_train <- c(1:nrow(X))[-ind_valts]
  xtrain <- X[ind_train,] 
  ztrain=Z[ind_train,] 
  ytrain=yused[ind_train] 
  xtest=X[ind_ts,] 
  ztest=Z[ind_ts,]
  ytest=yused[ind_ts]
  rf=randomFor(xtrain,ztrain,ytrain,xtest,ztest,ytest)

  
  