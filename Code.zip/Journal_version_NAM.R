library('parallel')


sgd_int=function(xtrain,ztrain,ytrain,xtest,ztest,ytest,xval,zval,yval,basis,sd_y,mu,gamma,totit,bts)
{
  
  p=ncol(xtrain)
  q=ncol(ztrain)
  
  
  ####K means clustering to get the mu and gamma for the following##############
  
  kmeans_mu=kmeans(mu,basis,iter.max = 50, nstart = 25)
  kmeans_gamma=kmeans(gamma, basis,iter.max = 50, nstart = 25)
  
  mu=kmeans_mu$centers
  gamma=kmeans_gamma$centers
  kx=ky=dim(mu)[1]
  
  theta=runif(kx)
  beta=runif(ky)
  eta=theta
  eps=beta
  zeta=mu
  omg=gamma
  tau=0.01
  
  #sig2=sig1=1.1
  
  sig1=(mean(dist(mu)))^2*2  ## Try running it later and see if it gives better/similar result
  sig2=(mean(dist(gamma)))^2*2
  
  exp_f=function(d,par1,par2,sign)
  {
    
    temp=rep(0.0,dim(d)[1])
    tmod_r=matrix(0.0,dim(par2)[1],dim(d)[1])
    dmod_r=matrix(0.0,dim(par2)[2],dim(d)[1])
    for(k in 1:dim(par2)[1]){
      dmod=t(d)-rep(par2[k,], nrow(d))
      dmod_r=dmod
      tmod=exp(-(colSums(dmod**2)/sign))
      tmod_r[k,]=tmod
      temp=temp+par1[k]*tmod
    }
    return(list("value"=temp,"dtb"= tmod_r,"x_p1"=dmod_r))
  }
  
  loss_fun=function(X,Z,y,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
  {
    #print(dim(X))
    fx_f=exp_f(X,theta,mu,sig1)
    fx=fx_f$value
    gx_f=exp_f(Z,beta,gamma,sig2)
    gx=gx_f$value
    f1x_f=exp_f(X,eta,zeta,sig1)
    f1x=f1x_f$value
    g1x_f=exp_f(Z,eps,omg,sig2)
    g1x=g1x_f$value
    L=sum(abs(y-fx-gx-tau*f1x*g1x))*(1/length(y))
    L_new=list("L"=L,"gx"=gx,"fx"=fx,"gx_f"=gx_f,"fx_f"=fx_f,"g1x"=g1x,"f1x"=f1x,"g1x_f"=g1x_f,"f1x_f"=f1x_f)
    return(L_new)
    
  }
  
  loss_fun_test=function(xnew, znew, ynew,kappa, mean_y,sd_y,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
  {
    fx_f=exp_f(xnew,theta,mu,sig1)
    fx=fx_f$value
    gx_f=exp_f(znew,beta,gamma,sig2)
    gx=gx_f$value
    f1x_f=exp_f(xnew,eta,zeta,sig1)
    f1x=f1x_f$value
    g1x_f=exp_f(znew,eps,omg,sig2)
    g1x=g1x_f$value
    y_pred=fx+gx+kappa+tau*f1x*g1x
    #y_pred=y_pred*sd_y+mean_y
    L=sum(abs(ynew-y_pred))*(1/length(ynew))*(sd_y)
    L_new=list("L"=L,"gx"=gx,"fx"=fx,"gx_f"=gx_f,"fx_f"=fx_f,"f1x"=f1x,"g1x"=g1x,"f1x_f"=f1x_f
               ,"g1x_f"=g1x_f)
    return(L_new)
  }
  
  dldtb=function(y,fx_f,gx_f, fx, gx,f1x,g1x,tau)
  {
    n=length(y)
    dldth=0.0
    dldb=0.0
    # for (i in 1:length(y)){
    dldth=fx_f$dtb%*%sign(y-fx-gx-tau*f1x*g1x)
    dldb=gx_f$dtb%*%sign(y-fx-gx-tau*f1x*g1x)
    #}
    dldth=(-1/n)*dldth
    dldb=(-1/n)*dldb
    return(list('dldth'=t(dldth),'dldb'=t(dldb)))
  }
  
  dldm=function(X,y,k,mu1,theta1,fx_f,fx, gx,sig1,f1x,g1x,tau)
  {
    dldmu=0.0
    
    dldmu=t(theta1[k]*t(t(X)-mu1[k,])*(fx_f$dtb[k,]))%*%sign(y-fx-gx-tau*f1x*g1x)
    #}
    return(array((-2*dldmu)/(sig1*length(y))))
  }
  
  
  dldg=function(Z,y,k,gamm1,beta1,gx_f,gx, fx,sig2,f1x,g1x,tau)
  { 
    
    dldgm=0.0
    
    dldgm=t(beta1[k]*t(t(Z)-gamm1[k,])*(gx_f$dtb[k,]))%*%sign(y-fx-gx-tau*f1x*g1x)
    #}
    return(array((-2*dldgm)/(sig2*length(y))))
  }
  
  dmug=function(X,Z,y,beta1,theta1,mu1,gamm1,sig1,sig2,eta1,zeta1,eps1,omg1,tau1,f1x,g1x)
  {
    
    L=loss_fun(X,Z,y,beta1,theta1,mu1,gamm1,eta1,zeta1,eps1,omg1,tau1,sig1,sig2)
 
    dldmu_ul<-mcmapply(seq(1,kx,1), FUN=dldm,MoreArgs = list(X=X,y=y,mu1=mu1,theta1=theta1,fx_f=L$fx_f,fx=L$fx, gx=L$gx,sig1=sig1,f1x=L$f1x,g1x=L$g1x,tau=tau1),mc.cores=1)
    
    
    
    dldgm_ul=mcmapply(seq(1,ky,1), FUN=dldg,MoreArgs = list(Z=Z,y=y,gamm1=gamm1,beta1=beta1,gx_f=L$gx_f,gx=L$gx,fx=L$fx,sig2=sig2,f1x=L$f1x,g1x=L$g1x,tau=tau1),mc.cores=1)
    return(list("dldmu_ul"=t(dldmu_ul),"dldgm_ul"=t(dldgm_ul)))
    
  }
  
  dldeteps=function(y,fx,gx,f1x_f,g1x_f, f1x, g1x,tau)
  {
    
    dldet=0.0
    dldeps=0.0
    # for (i in 1:length(y)){
    
    dldet=f1x_f$dtb%*%(g1x*sign(y-fx-gx-tau*f1x*g1x))
    
    dldeps=g1x_f$dtb%*%(f1x*sign(y-fx-gx-tau*f1x*g1x))
    
    #}
    
    dldet=(-1/length(y))*dldet
    dldeps=(-1/length(y))*dldeps
    return(list('dldet'=t(dldet),'dldeps'=t(dldeps)))
  }
  
  dldzet=function(X,y,k,zeta1,eta1,f1x_f,f1x, g1x,sig1,fx,gx,tau)
  {
    dldzet=0.0
    
    dldzet=t(eta1[k]*t(t(X)-zeta1[k,])*(f1x_f$dtb[k,]))%*%(g1x*sign(y-fx-gx-tau*f1x*g1x))
    
    #}
    return(array((-2*dldzet)/(sig1*length(y))))
  }
  
  dldomg=function(Z,y,k,omg1,eps1,g1x_f,g1x, f1x,sig2,fx,gx,tau)
  { 
    
    dldomg=0.0
    
    dldomg=t(eps1[k]*t(t(Z)-omg1[k,])*(g1x_f$dtb[k,]))%*%(f1x*sign(y-fx-gx-tau*f1x*g1x))
    
    #}
    return(array((-2*dldomg)/(sig2*length(y))))
  }
  
  dzetomg=function(X,Z,y,eta1,eps1,zeta1,omg1,sig1,sig2,beta1,theta1,mu1,gamm1,tau1,fx,gx)
  {
 
    L=loss_fun(X,Z,y,beta1,theta1,mu1,gamm1,eta1,zeta1,eps1,omg1,tau1,sig1,sig2)
    
    
    dldzet_ul<-mcmapply(seq(1,kx,1), FUN=dldzet,MoreArgs = list(X=X,y=y,zeta1=zeta1,eta1=eta1,f1x_f=L$f1x_f,f1x=L$f1x, g1x=L$g1x,sig1=sig1,fx=L$fx,gx=L$gx,tau=tau1),mc.cores=1)
    
    
 
    dldomg_ul=mcmapply(seq(1,ky,1), FUN=dldomg,MoreArgs = list(Z=Z,y=y,omg1=omg1,eps1=eps1,g1x_f=L$g1x_f,g1x=L$g1x,f1x=L$f1x,sig2=sig2,fx=L$fx,gx=L$gx,tau=tau1),mc.cores=1)
    return(list("dldzet_ul"=t(dldzet_ul),"dldomg_ul"=t(dldomg_ul)))
    
  }
  
  sgd_grad_desc=function(X,Z,y,xtest,ztest,ytest,xval,zval,yval,theta,mu,beta,gamma,eta,zeta,eps,omg,tau,
                         sig1,sig2,Total_itr = 10000,lr0=0.1,lrdecay=0.009,kx,ky,user=1,doplot=T,batch=4000,
                         si=1,graph_ind=1,delta=0.9,rate,sd_y)
  {
    lr=lr0
    
    
    
    momentum_eteps=matrix(0.0,kx,2)
    momentum_tb=matrix(0.0,kx,2) #1st col for theta
    momentum_m=matrix(0.0,kx,p)
    momentum_g=matrix(0.0,ky,q)
    momentum_zeta=matrix(0.0,kx,p)
    momentum_omg=matrix(0.0,ky,q)
    
    kappa=0.0
    
    n = length(y) 
    
    
    
    
    
    
    
    
    lossvec = rep(0.0,Total_itr)
    lossvec_test = rep(0.0,Total_itr)
    old_itr=200
    count=0
    
    for (itr in 1:Total_itr)
    {
      
      if(itr<=Total_itr)
      {
        
        
        
        theta20 = theta
        beta20 = beta
        mu20=mu
        gamma20=gamma
        eta20=eta
        zeta20=zeta
        eps20=eps
        omg20=omg
        tau20=tau
        
        sig120=sig1
        sig220=sig2
        
        temp=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
        kappa=median(y-temp$fx-temp$gx-tau*temp$f1x*temp$g1x)
        
        temp=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
        lossold=temp$L
        lossnew = lossold
        
        deriv1=dldtb(y-kappa,temp$fx_f,temp$gx_f, temp$fx, temp$gx,temp$f1x,temp$g1x,tau)
        derivbeta = deriv1$dldb
        derivtheta = deriv1$dldth  # Derivative wrt beta1
        deriv2=dldeteps(y-kappa,temp$fx,temp$gx, temp$f1x_f, temp$g1x_f,temp$f1x,temp$g1x,tau)
        derivet=deriv2$dldet 
        deriveps=deriv2$dldeps
        dmg=dmug(X,Z,y-kappa,beta,theta,mu,gamma,sig1,sig2,eta,zeta,eps,omg,tau,temp$f1x,temp$g1x)
        derivmu=dmg$dldmu_ul
        derivgm=dmg$dldgm_ul
        dzo=dzetomg(X,Z,y-kappa,eta,eps,zeta,omg,sig1,sig2,beta,theta,mu,gamma,tau,temp$fx,temp$gx)
        derivzet=dzo$dldzet_u
        derivomg=dzo$dldomg_ul
        
        theta= theta20 - lr *( derivtheta+tau20*derivet)+delta*momentum_tb[,1] 
        mu=mu20- lr * (derivmu+tau20*derivzet)+delta*momentum_m
        beta = beta20 - lr * (derivbeta+tau20*deriveps) +delta*momentum_tb[,2] 
        gamma=gamma20-lr* (derivgm+tau20*derivomg)+delta*momentum_g
 
        if(itr > 100){
          eta=theta
          zeta=mu
          eps=beta
          omg=gamma
          tau=tau20-lr*(1/length(y))*(-sum(sign(y-kappa-temp$fx-temp$gx-tau20*temp$f1x*temp$g1x)*temp$f1x*temp$g1x))
          
        } 
        
        temp=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
        kappa=median(y-temp$fx-temp$gx-temp$f1x*temp$g1x)
        
        temp=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
        lossnew=temp$L
        L1 = lr
        changeL = 0
        check=0
        while(lossnew > lossold )
        {  
          changeL = changeL + 1
          L1 = L1*0.9 
          
          if(graph_ind==1) 
          {
            beta = beta20 - L1 * (derivbeta+tau20*deriveps) +delta*momentum_tb[,2] # Update beta1
            gamma=gamma20-L1* (derivgm+tau20*derivomg) +delta*momentum_g
          }
          
          theta= theta20 - L1 * ( derivtheta+tau20*derivet)+delta*momentum_tb[,1]
          mu=mu20- L1 * (derivmu+tau20*derivzet)+delta*momentum_m
          
          
          if(itr > 100){
            eta=theta
            zeta=mu
            eps=beta
            omg=gamma
            tau=tau20-L1*(1/length(y))*(-sum(sign(y-kappa-temp$fx-temp$gx-tau20*temp$f1x*temp$g1x)*temp$f1x*temp$g1x))
            
            
          }
          
          temp=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
          kappa=median(y-temp$fx-temp$gx-tau*temp$f1x*temp$g1x)
          #print(kappa)
          temp=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
          lossnew=temp$L
          #print(lossnew)
          
          if(changeL > 20)
          {   
            
            theta = theta20
            beta = beta20
            mu=mu20
            gamma=gamma20
            
            eta=theta20
            zeta=mu20
            eps=beta20
            omg=gamma20
            tau=tau20
            check=1
            
            
            break 
            
          }
        }
        
        
        
        lossvec[itr]=  lossold
        
    
        
      }
      
      lossvec_test[itr]=  loss_fun_test(xtest,ztest,ytest,kappa,mean_y,sd_y,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)$L
   
      
      if(itr%%100==0)
      { 
        if(doplot)
          plot((itr-99):itr, lossvec_test[(itr-99):itr])
        
      }
      
      
      
      if(user==0)  
      {
        
        print(paste(itr, lossvec_test[itr]))
      }
      if(itr>100 && lossvec[itr]==lossvec[itr-100])
      { 
        break
        
      }
     
    }
    final_func=loss_fun(X,Z,y-kappa,beta,theta,mu,gamma,eta,zeta,eps,omg,tau,sig1,sig2)
    
    
    return(list('lossv'=lossvec,'lossv_test'=lossvec_test,'theta_min'=theta,'mu_min'=mu,'beta_min'
                =beta,'gamm_min'=gamma,'eta_min'=eta,'eps_min'=eps,'zeta_min'=zeta,'omg_min'=omg,'tau_min'=tau,'kappa'=kappa,'sig1_min'=sig1,'sig2_min'=sig2,'itr'=itr,'final_func'=final_func))
  }
  
  modl_sgd=sgd_grad_desc(xtrain,ztrain,ytrain,xtest,ztest,ytest,xval,zval,yval,theta,mu,beta,gamma,eta,zeta,eps,omg,tau,sig1=3.0,sig2=3.0,Total_itr =totit,lr0=1.0,lrdecay=0.2,kx,ky,user=1,doplot=F,
                         batch=bts,si=0.1,graph_ind = 1,delta=0.0,rate=1.0,sd_y)
  

  return(modl_sgd)
  
}

load('/work/users/s/a/sampriti/ML_2_drug/mu_gamma_form.rda')
mu=mu_form[-1,]
gamma=gamma_form[-1,]

#data=load('/work/users/s/a/sampriti/ML_2_drug/ML2_full.rda')
data=load('/work/users/s/a/sampriti/ML_2_drug/Interaction_effect/XYZ_wtm231.rda')
loops=30


residual=lm(y~X$MolWt+X$MolLogP)$residual 
yused=residual
#colnames(X)[c(1,2,3,5,6,7,16)]'MolLogP','MolWt','NumHAcceptors','NumHeteroatoms','MolMR','NumHDonors','BalabanJ
X=X[,-c(1,2,3,7,16)] 
mu=mu[,-c(1,2,3,7,16)]

sd_y=diff(range(yused))#sd(y)
mean_yused=min(yused)+0.5*sd_y
yused=(yused-mean_yused)/sd_y


  #set.seed(i)
  ind_valts<-sample(1:nrow(X),800)
  ind_vali <- sample(nrow(X), 800)
  ind_val <- ind_valts[ind_vali]
  ind_ts  <- ind_valts
  ind_train <- c(1:nrow(X))[-ind_valts]
  
  temp_ind=c(1:length(y))
  #sd_y=1.0
  xtrain <- X[ind_train,] 
  ztrain=Z[ind_train,] 
  ytrain=yused[ind_train] 
  xtest=X[ind_ts,] 
  ztest=Z[ind_ts,]
  ytest=yused[ind_ts]
  xval=NULL
  zval=NULL
  yval=NULL
  sgd_res=sgd_int(xtrain,ztrain,ytrain,xtest,ztest,ytest,xval,zval,yval,5,sd_y=sd_y,mu,gamma,20000,nrow(xtrain))






