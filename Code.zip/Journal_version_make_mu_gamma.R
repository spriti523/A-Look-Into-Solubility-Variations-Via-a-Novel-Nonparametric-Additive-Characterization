#### dividing fragment######
data=load('/pine/scr/s/a/sampriti/ML_2_drug/ML2_full.rda')
mu_baes=0 #(max(y)-min(y))/(2*(kx+ky))
sig_baes=1
mu_form=array(0.0,p)
gamma_form=array(0.0,q)
d=600
for(i in 1:10)
{ 
  gc()
  ind=seq(((i-1)*d+1),d*i)
  kx=ky=30
  sig1=sig2=1.1
  theta=rnorm(kx,mu_baes,sig_baes)
  mu=matrix(rnorm(p*kx,0.25,1.1),kx,p)
  beta=rnorm(ky,mu_baes,sig_baes)
  gamma=matrix(rnorm(q*ky,0.25,1.1),ky,q)
  form_mod=grad_desc(X[ind,],Z[ind,],y[ind],theta,mu,beta,gamma,sig1,sig2,2000,0.2,kx,ky,1,F)
  mu_form=rbind(mu_form,form_mod$mu_min)
  gamma_form=rbind(gamma_form,form_mod$gamm_min)
  print(i)
  plot(form_mod$lossv)
}



mu=mu_form[-1,]
gamma=gamma_form[-1,]

save(mu_form,gamma_form,file='/pine/scr/s/a/sampriti/ML_2_drug/mu_gamma_form.rda')