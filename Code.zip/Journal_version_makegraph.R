data_drug<-read.csv('/pine/scr/s/a/sampriti/ML_2_drug/curated-solubility-dataset.csv',
                    header=TRUE,sep = ",", quote = "\"")
data_drug_mat<-matrix(0.0,dim(data_drug)[1],21)


for( i in 6:26){
  data_drug_mat[,i-5]<-as.numeric(data_drug[,i])
}
colnames(data_drug_mat)<-colnames(data_drug[,6:26])
data_drug_mat=data_drug_mat[,-c(2,3,4)]
#image.plot(cor(scale(data_drug_mat)),col=viridis(50))
#image.plot(cov(data_drug_mat))
# library(reticulate)
# np <- import("numpy")


### Calculations using the adjacency matrix#####3
library(igraph)
install.packages('NetworkToolbox', repos='http://cran.us.r-project.org')
library('NetworkToolbox')
install.packages('brainGraph', repos='http://cran.us.r-project.org')
library('brainGraph')
path="~/Documents/vestalab/ML_2_drug/solubility/adjacency_trial/weighted_mat/adj"
feat_mat=rep(0.0,8)
#for (i in 0:10)
par=function(i)
{
  # i=858
  ge=out_clcoef=PL_aspl=PL_d=bwn=nod_imp=lev=ptn=stbl=stg=score=deg=evec=NA
  path="~/Documents/vestalab/ML_2_drug/solubility/adjacency_trial/weighted_mat/adj"
  path=paste(path,i,".csv",sep="")
  
  
  adj <- read.csv(path)
  adj_new<-as.matrix(adj[,-1])
  lower_t=sum(adj_new[upper.tri(adj_new,diag=F)])
  if(nrow(adj_new)>3 && lower_t!=0.0)
  {
    
    
    
    g<-graph_from_adjacency_matrix(adj_new, mode = "undirected",)
    ge=global_efficiency(g, directed = FALSE)
    
    out_clcoef=clustcoeff(adj_new,weighted = T)
    out_clcoef=out_clcoef$CC
    # smw=smallworldness(adj_new,iter=dim(adj_new)[1])
    # smw=smw$swm
    bwn=mean(NetworkToolbox::betweenness(adj_new))
    
    nod_imp=mean(impact(adj_new))
    
    
    
    lev=mean(leverage(adj_new,weighted = TRUE))
    pt=participation(adj_new)
    ptn=mean(pt$overall)
    PL=pathlengths(adj_new,weighted = TRUE)
    PL_aspl=PL$ASPL
    PL_d=PL$diameter
    stbl=mean(stable(adj_new))
    stg=mean(igraph::strength(g))
    score=mean(s_core(g))
    deg=mean(igraph::degree(g))
    evec=mean(NetworkToolbox::eigenvector(adj_new,weighted = TRUE))
    # if(i==0)
    #{
  }
  return(c(ge,out_clcoef,PL_aspl,PL_d,bwn,nod_imp,lev,ptn,stbl,stg,score,deg,evec))
  # next
  # }
}

#feat_mat=rbind(feat_mat,c(ge,out_clcoef,PL_aspl,PL_d,bwn_avg,nod_imp,lev,ptn,stbl,stg,
#score,deg,evec))

library(parallel)

feat_mat=matrix(NA,9981,13)



for(i in 0:100)
{ 
  gc()
  
  try_out=try(temp<-par(i),silent=TRUE)
  if(length(try_out)==13)
  {
    feat_mat[i+1,]=temp
  }
  print(paste("in",i))
}

feat_mat=data.frame(as.matrix(feat_mat))
fmat<-feat_mat

ind=which(is.na(rowSums(fmat)))
fmat<-fmat[-ind,]

#feat_mat=mcmapply(0:5000,FUN=par,mc.cores = 6)



colnames(fmat)=c("ge","out_clcoef","PL_aspl","PL_d","bwn","nod_imp","lev","ptn","stbl","stg","score","deg","evec")
#rownames(fmat)=c(rep("",nrow(fmat)))
#plot(g)

write.csv(fmat,file="~/Documents/vestalab/ML_2_drug/solubility/adjacency_trial/adjfmat_wmat.csv")
write.csv(data.frame(data_drug_mat),file="/pine/scr/s/a/sampriti/ML_2_drug/data_drug.csv",sep = "",quote = TRUE)
